<?php

require "../classes/Categoria.php";


if ($_SERVER['REQUEST_METHOD'] === 'GET') {

    $categoria = new Categoria();

    $dados = $categoria->listarCategoria();

    // foreach($dados as $key){ 
    //     echo ($key["CATNOME"]."\n");
    // }

    echo json_encode($dados);
}